package br.com.fundatec.microservicecourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceCourseApplicationTests {

	@Test
	void contextLoads() {
	}
}
