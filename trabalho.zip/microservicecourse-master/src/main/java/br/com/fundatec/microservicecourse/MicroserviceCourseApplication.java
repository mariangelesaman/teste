package br.com.fundatec.microservicecourse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceCourseApplication {

	public static void main(String[] args) {

		SpringApplication.run(MicroserviceCourseApplication.class, args);
	}
}
