package br.com.fundatec.microservicecourse.controller;

public class VeterinarioRequest {
	
	private Long veterinarioId;

	public Long getVeterinarioId() {
		return veterinarioId;
	}

	public void setVeterinarioId(Long veterinarioId) {
		this.veterinarioId = veterinarioId;
	}
}
